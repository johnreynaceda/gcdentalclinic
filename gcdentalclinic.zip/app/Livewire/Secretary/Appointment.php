<?php

namespace App\Livewire\Secretary;

use Livewire\Component;

class Appointment extends Component
{
    public function render()
    {
        return view('livewire.secretary.appointment');
    }
}
