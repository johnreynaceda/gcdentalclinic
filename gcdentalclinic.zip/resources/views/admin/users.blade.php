@section('title', 'Users')
<x-admin-layout>
    <div>
        <livewire:admin.user-list />
    </div>
</x-admin-layout>
