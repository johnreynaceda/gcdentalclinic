@section('title', 'Services')
<x-admin-layout>
    <div>
        <livewire:admin.service-list />
    </div>
</x-admin-layout>
