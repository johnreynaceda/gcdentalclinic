@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        coming soon,
    </div>
</x-admin-layout>
