<div>
    <div class="bg-white p-10  rounded-2xl">
        {{ $this->table }}
    </div>
</div>
