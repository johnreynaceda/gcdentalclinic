@section('title', 'Billing')
<x-admin-layout>
    <div>
        <livewire:secretary.billing />
    </div>
</x-admin-layout>
