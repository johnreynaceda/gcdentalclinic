@section('title', 'Appointments')
<x-admin-layout>
    <div>
        <livewire:secretary.appointments />
    </div>
</x-admin-layout>
