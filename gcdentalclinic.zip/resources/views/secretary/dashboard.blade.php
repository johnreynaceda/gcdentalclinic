@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        <livewire:secretary.dashboard />
    </div>
</x-admin-layout>
