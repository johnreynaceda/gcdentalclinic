@section('title', 'Schedules')
<x-admin-layout>
    <div>
        <livewire:admin.schedule-list />
    </div>
</x-admin-layout>
