<img src="{{ asset('images/gclogo.png') }}" {{ $attributes }} alt="">
