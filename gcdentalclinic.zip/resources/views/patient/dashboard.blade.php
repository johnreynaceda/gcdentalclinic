
<x-patient-layout>
    <div>
        {{-- <livewire:patient.dashboard /> --}}
    </div>
</x-patient-layout>
