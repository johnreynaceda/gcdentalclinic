<x-patient-layout>
    <div>
        <livewire:patient.services />
    </div>
</x-patient-layout>
