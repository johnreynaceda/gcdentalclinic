<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <style>
        [x-cloak] {
            display: none !important;
        }

        .dropdown-menu {
            display: none;
        }

        .dropdown-menu.show {
            display: block;
        }

        .appoint-button {
            background-color: #3B82F6;
            color: white;
            border-radius: 0.375rem;
            text-align: center;
            display: inline-block;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        .appoint-button:hover {
            background-color: #2563EB;
        }
    </style>


    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="font-sans antialiased bg-gray-100">
    <div class="fixed">
        <img src="<?php echo e(asset('images/bg.jpg')); ?>" class="opacity-5" alt="">
    </div>

    

    <section class="relative w-full px-8 text-gray-700 sticky top-0 bg-main z-20 body-font"
        data-tails-scripts="//unpkg.com/alpinejs" <?php echo $attributes ?? ''; ?>>
        <div class="container flex flex-col flex-wrap items-center justify-between py-5 mx-auto md:flex-row max-w-7xl">
            <a href="#_"
                class="relative z-10 flex space-x-2 items-center w-auto text-2xl font-bold leading-none text-white select-none">
                <img src="<?php echo e(asset('images/gclogo.png')); ?>" class="h-12" alt="">
                <span>GC DENTAL</span>
            </a>

            <nav
                class="top-0 left-0 z-0 flex items-center justify-center w-full h-full py-5 -ml-0 space-x-5 text-base md:-ml-5 md:py-0 md:absolute">
                <a href="<?php echo e(route('patient.dashboard')); ?>"
                    class="relative font-medium leading-6 transition duration-150 ease-out text-white hover:text-gray-900">
                    <span class="block">Home</span>
                </a>
                <a href="<?php echo e(route('patient.appointment')); ?>"
                    class="relative font-medium leading-6 transition duration-150 ease-out text-white hover:text-gray-900">
                    <span class="block">Appointment</span>
                </a>
                <a href="<?php echo e(route('patient.services')); ?>"
                    class="relative font-medium leading-6 transition duration-150 ease-out text-white hover:text-gray-900">
                    <span class="block">Services</span>
                </a>

            </nav>

            <div class="relative z-10 inline-flex items-center space-x-3 md:ml-5 lg:justify-end">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('userdropdown', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-139183163-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </section>


    <div class="flex flex-col min-h-screen relative z-10">
        <div class="flex-1">
            <div class="relative flex-1 overflow-y-auto focus:outline-none">
                <main class="mx-auto max-w-7xl py-10">
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>
    </div>


    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH E:\FREELANCE PROJECTS\gcdentalclinic\resources\views/components/patient-layout.blade.php ENDPATH**/ ?>