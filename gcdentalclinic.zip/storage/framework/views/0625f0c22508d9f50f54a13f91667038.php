<div>
    <div>
        <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="bg-green-500 text-white p-4 rounded-lg mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <?php if(session()->has('error')): ?>
            <div class="bg-red-500 text-white p-4 rounded-lg mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="grid grid-cols-3 gap-10 relative">
        <div class="col-span-2">

            <div class="mb-10 flex space-x-4 items-center">
                <button wire:click="$set('selected_category', null)"
                    class="<?php echo e($selected_category == null ? 'bg-main text-white' : ''); ?> rounded-2xl p-2 px-4 border-main hover:bg-main hover:text-white border-2">
                    <span>All</span>
                </button>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <button wire:click="$set('selected_category', <?php echo e($item->id); ?>)"
                        class="<?php echo e($selected_category == $item->id ? 'bg-main text-white' : ''); ?> rounded-2xl p-2 px-4 border-main hover:bg-main hover:text-white border-2">
                        <span><?php echo e($item->name); ?></span>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No categories available</p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>


            <div class="containner mx-auto">
                <div class="space-y-3">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex px-4 bg-white rounded-xl items-start space-x-3 py-6">
                            <input type="checkbox" wire:click="toggleService(<?php echo e($item->id); ?>)"
                                class="border-gray-300 rounded h-5 w-5"
                                <?php echo e(in_array($item->id, $selectedServiceIds) ? 'checked' : ''); ?> />
                            <div class="flex flex-col">
                                <h1 class="text-gray-700 font-medium leading-none"><?php echo e($item->name); ?></h1>
                                <h1 class="mt-1">&#8369;<?php echo e(number_format($item->price)); ?></h1>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <!-- Selected Services and Total Fee -->      <div>
            <div class="border rounded-3xl flex flex-col bg-white p-5 h-[40rem]">
                <div class="flex-1 space-y-4">
                    <h3 class="text-xl font-semibold">Selected Services</h3>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $selectedServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex justify-between">
                            <span><?php echo e($service->name); ?></span>
                            <span>&#8369;<?php echo e(number_format($service->price)); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No services selected</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="flex justify-between font-semibold mt-4 border-t pt-2">
                        <span>Total Fee</span>
                        <span>&#8369;<?php echo e(number_format($totalFee)); ?></span>
                    </div>
                </div>
                <button wire:click="openModal"
                    class="w-full bg-main p-2.5 rounded-2xl text-white font-semibold text-lg hover:bg-gray-600">
                    <span>Continue</span>
                </button>
            </div>
        </div>
    </div>


    <div x-data="{ open: <?php if ((object) ('showModal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showModal'->value()); ?>')<?php echo e('showModal'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showModal'); ?>')<?php endif; ?> }" x-show="open" class="fixed inset-0 flex items-center justify-center z-50"
        style="display: none;">
        <div class="bg-white rounded-lg shadow-lg p-6 max-w-lg mx-auto">
            <h3 class="text-lg font-semibold">Confirm Appointment</h3>
            <p>Please enter the appointment date and time:</p>
            <div class="mt-4">
                <label for="appointmentDate" class="block text-sm font-medium text-gray-700">Appointment Date</label>
                <input type="date" wire:model.defer="appointmentDate"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['appointmentDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mt-4">
                <label for="appointmentTime" class="block text-sm font-medium text-gray-700">Appointment Time</label>
                <input type="time" wire:model.defer="appointmentTime"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['appointmentTime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button @click="open = false" class="text-gray-500 hover:text-gray-700">Cancel</button>
                <button wire:click="submitAppointment" class="bg-main text-white p-2 rounded">Confirm</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\gcdentalclinic\resources\views/livewire/patient/services.blade.php ENDPATH**/ ?>