

<div class="bg-white p-10  rounded-2xl">
    <?php echo e($this->table); ?>

</div>
<?php /**PATH E:\FREELANCE PROJECTS\gcdentalclinic\resources\views/livewire/secretary/records.blade.php ENDPATH**/ ?>