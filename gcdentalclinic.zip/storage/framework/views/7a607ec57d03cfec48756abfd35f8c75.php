<div class="p-6  min-h-screen">

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal9b945b32438afb742355861768089b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b945b32438afb742355861768089b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.card','data' => ['class' => 'shadow-lg hover:shadow-xl transition-shadow duration-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'shadow-lg hover:shadow-xl transition-shadow duration-300']); ?>
                <div class="flex flex-col justify-between h-full">

                    <div>
                        <h3 class="text-xl font-bold text-gray-800 mb-2"><?php echo e($appointment->service->name); ?></h3>
                        <p class="text-gray-600">Appointment Date:
                            <?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('F d, Y')); ?></p>
                        <p class="text-gray-600">Time:
                            <?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('h:i A')); ?></p>
                        <p class="text-gray-600 mb-4">Status:
                            <span
                                class="font-semibold <?php echo e($appointment->status === 'approved' ? 'text-green-600' : ($appointment->status === 'declined' ? 'text-red-600' : 'text-yellow-500')); ?>">
                                <?php echo e(ucfirst($appointment->status) ?? 'Pending'); ?>

                            </span>
                        </p>
                    </div>


                    <div class="flex justify-between items-center mt-4">
                        <span
                            class="text-xl font-semibold text-gray-800">₱<?php echo e(number_format($appointment->total_fee, 2)); ?></span>
                        <!--[if BLOCK]><![endif]--><?php if($appointment->status == 'pending'): ?>
                            <button
                                class="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors duration-200">
                                View Details
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b945b32438afb742355861768089b04)): ?>
<?php $attributes = $__attributesOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__attributesOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b945b32438afb742355861768089b04)): ?>
<?php $component = $__componentOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__componentOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\gcdentalclinic\resources\views/livewire/patient/appointment.blade.php ENDPATH**/ ?>