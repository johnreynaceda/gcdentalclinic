
<div>
    <div class="bg-white p-10 rounded-xl">
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\gcdentalclinic\resources\views/livewire/secretary/appointments.blade.php ENDPATH**/ ?>