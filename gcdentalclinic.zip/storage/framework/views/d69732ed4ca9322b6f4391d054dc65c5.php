<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH E:\FREELANCE PROJECTS\gcdentalclinic\resources\views/livewire/secretary/billing.blade.php ENDPATH**/ ?>